/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;

/**
 * Classe responsavel pelo registo de um funcionario.
 *
 * @version 1.0
 */
public class Funcionario implements Serializable {
//  Código, apelido, nome completo, data de nascimento, nr de BI, sexo/ gênero, naturalidade, email, contatos, estado civil, endereço, salário, observação
    private String nome;
    private String apelido;
    private int codigo;
    private int nrBI;
    private String sexo;
    private String dataNascimento;
    private String naturalidade;
    private String email;
    private int contacto;
    private String estadoCivil;
    private String endereco;
    private double salario;
    private String observacao;

    public Funcionario() {
    }

    public Funcionario(String nome, String apelido, int codigo, int nrBI, String sexo, String dataNascimento, String naturalidade, String email, int contacto, String estadoCivil, String endereco, double salario, String observacao) {
        this.nome = nome;
        this.apelido = apelido;
        this.codigo = codigo;
        this.nrBI = nrBI;
        this.sexo = sexo;
        this.dataNascimento = dataNascimento;
        this.naturalidade = naturalidade;
        this.email = email;
        this.contacto = contacto;
        this.estadoCivil = estadoCivil;
        this.endereco = endereco;
        this.salario = salario;
        this.observacao = observacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getNrBI() {
        return nrBI;
    }

    public void setNrBI(int nrBI) {
        this.nrBI = nrBI;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getNaturalidade() {
        return naturalidade;
    }

    public void setNaturalidade(String naturalidade) {
        this.naturalidade = naturalidade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getContacto() {
        return contacto;
    }

    public void setContacto(int contacto) {
        this.contacto = contacto;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

   

  
   

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Funcionario other = (Funcionario) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Funcionario{" + "nome=" + nome + ", apelido=" + apelido + ", codigo=" + codigo + ", nrBI=" + nrBI + ", sexo=" + sexo + ", dataNascimento=" + dataNascimento + ", naturalidade=" + naturalidade + ", email=" + email + ", contacto=" + contacto + ", estadoCivil=" + estadoCivil + ", endereco=" + endereco + ", salario=" + salario + ", observacao=" + observacao + '}';
    }

   

}
