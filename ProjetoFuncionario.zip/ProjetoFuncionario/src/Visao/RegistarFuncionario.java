package Visao;

import Controlo.FuncionarioDAO;
import Modelo.Funcionario;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RegistarFuncionario extends javax.swing.JFrame {

    public RegistarFuncionario() {
        initComponents();
        readJTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        lblNome = new javax.swing.JLabel();
        jtfNome = new javax.swing.JTextField();
        jlblsexo = new javax.swing.JLabel();
        jcbSexo = new javax.swing.JComboBox<String>();
        lblDataDeIngresso = new javax.swing.JLabel();
        jtfDataDeNascimento = new javax.swing.JTextField();
        lblDataRegisto = new javax.swing.JLabel();
        jtfnrBI = new javax.swing.JTextField();
        lblCodigo = new javax.swing.JLabel();
        jtfCodigo = new javax.swing.JTextField();
        lblSalario = new javax.swing.JLabel();
        jbtGravar = new javax.swing.JButton();
        jbtPesquisar = new javax.swing.JButton();
        jbtLimpar = new javax.swing.JButton();
        jbtActualizar = new javax.swing.JButton();
        jbtRemover = new javax.swing.JButton();
        jtfSalario = new javax.swing.JTextField();
        lblApelido = new javax.swing.JLabel();
        jtfapelido = new javax.swing.JTextField();
        jblEmail = new javax.swing.JLabel();
        jtfEmail = new javax.swing.JTextField();
        jlblenderco = new javax.swing.JLabel();
        jtfEndereco = new javax.swing.JTextField();
        jlblContacto = new javax.swing.JLabel();
        jtfContacto = new javax.swing.JTextField();
        jblObservacao = new javax.swing.JLabel();
        jlblEstadoCivil = new javax.swing.JLabel();
        jtfEstadoCivil = new javax.swing.JTextField();
        jlblNaturalidade = new javax.swing.JLabel();
        jtfNaturalidade = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtfaObservacao = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nome", "Data Nascimento", "Apelido", "contacto", "Email", "Endereco", "Naturalidade", "Nr BI", "Estado Civil", "OBS", "Sexo", "Salario"
            }
        ));
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaMouseClicked(evt);
            }
        });
        tabela.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tabelaAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tabela);
        tabela.getColumnModel().getColumn(3).setResizable(false);

        lblNome.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblNome.setText("Nome");

        jtfNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfNomeActionPerformed(evt);
            }
        });

        jlblsexo.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jlblsexo.setText("Sexo");

        jcbSexo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "masculino", "femenino" }));
        jcbSexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbSexoActionPerformed(evt);
            }
        });

        lblDataDeIngresso.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblDataDeIngresso.setText("Data de Nascimento");

        jtfDataDeNascimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfDataDeNascimentoActionPerformed(evt);
            }
        });

        lblDataRegisto.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblDataRegisto.setText("numero de BI");

        lblCodigo.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblCodigo.setText("Codigo");

        lblSalario.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblSalario.setText("Salario");

        jbtGravar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtGravar.setText("Gravar");
        jbtGravar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtGravarActionPerformed(evt);
            }
        });

        jbtPesquisar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtPesquisar.setText("Pesquisar");
        jbtPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtPesquisarActionPerformed(evt);
            }
        });

        jbtLimpar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtLimpar.setText("Limpar");
        jbtLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtLimparActionPerformed(evt);
            }
        });

        jbtActualizar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtActualizar.setText("Actualizar");
        jbtActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtActualizarActionPerformed(evt);
            }
        });

        jbtRemover.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtRemover.setText("Remover");
        jbtRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtRemoverActionPerformed(evt);
            }
        });

        jtfSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfSalarioActionPerformed(evt);
            }
        });

        lblApelido.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblApelido.setText("Apelido");

        jblEmail.setText("Email");

        jlblenderco.setText("Endereço");

        jlblContacto.setText("Contacto");

        jblObservacao.setText("Observação");

        jlblEstadoCivil.setText("Esatado Civil");

        jlblNaturalidade.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jlblNaturalidade.setText("Naturalidade");

        jtfNaturalidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfNaturalidadeActionPerformed(evt);
            }
        });

        jtfaObservacao.setColumns(20);
        jtfaObservacao.setRows(5);
        jScrollPane2.setViewportView(jtfaObservacao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jbtGravar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNome, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDataDeIngresso, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblApelido)
                                    .addComponent(jblEmail)
                                    .addComponent(jlblContacto)
                                    .addComponent(jlblNaturalidade))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jtfNome, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                            .addComponent(jtfCodigo, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                            .addComponent(jtfEmail)
                                            .addComponent(jtfContacto)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addComponent(jbtPesquisar)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(131, 131, 131)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jlblsexo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblDataRegisto, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblSalario)
                                            .addComponent(jlblenderco)
                                            .addComponent(jblObservacao)
                                            .addComponent(jlblEstadoCivil))
                                        .addGap(26, 26, 26)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jcbSexo, 0, 188, Short.MAX_VALUE)
                                            .addComponent(jtfnrBI, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                                            .addComponent(jtfSalario)
                                            .addComponent(jtfEndereco)
                                            .addComponent(jtfEstadoCivil)
                                            .addComponent(jScrollPane2)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addComponent(jbtActualizar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jbtRemover)
                                        .addGap(83, 83, 83)
                                        .addComponent(jbtLimpar))))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtfDataDeNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtfapelido, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtfNaturalidade, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 787, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(jtfNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblsexo)
                    .addComponent(jcbSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDataRegisto)
                            .addComponent(jtfnrBI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblApelido)
                            .addComponent(jtfapelido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDataDeIngresso)
                    .addComponent(jtfDataDeNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblEstadoCivil)
                            .addComponent(jtfEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblNaturalidade)
                            .addComponent(jtfNaturalidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigo)
                    .addComponent(jtfCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSalario)
                    .addComponent(jtfSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jblEmail)
                    .addComponent(jtfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblenderco)
                    .addComponent(jtfEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jlblContacto)
                            .addComponent(jtfContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jblObservacao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(27, 27, 27)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtLimpar)
                    .addComponent(jbtPesquisar)
                    .addComponent(jbtGravar)
                    .addComponent(jbtActualizar)
                    .addComponent(jbtRemover))
                .addGap(67, 67, 67)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtfNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfNomeActionPerformed

    private void jcbSexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbSexoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcbSexoActionPerformed

    private void jtfDataDeNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfDataDeNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfDataDeNascimentoActionPerformed

    /**
     * Metodo reesponsavel por gravar o funcionario no ficheiro.
     *
     * @param evt
     */
    private void jbtGravarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtGravarActionPerformed

        Funcionario a = new Funcionario();
        a.setNome(jtfNome.getText());
        a.setApelido(jtfapelido.getText());
        a.setNaturalidade(jtfNaturalidade.getText());
        a.setEmail(jtfEmail.getText());
        a.setContacto(Integer.parseInt(jtfContacto.getText()));
        a.setEstadoCivil(jtfEstadoCivil.getText());
        a.setObservacao(jtfaObservacao.getText());
        a.setDataNascimento(jtfDataDeNascimento.getText());
        a.setSexo((String) jcbSexo.getSelectedItem());
        a.setNrBI(Integer.parseInt(jtfnrBI.getText()));
        a.setSalario(Double.parseDouble(jtfSalario.getText()));
        a.setEndereco(jtfEndereco.getText());
        

        FuncionarioDAO.create(a);

        jtfNome.setText(null);
        jtfDataDeNascimento.setText(null);
        jtfnrBI.setText(null);
        jcbSexo.setSelectedItem(null);
        jtfContacto.setText(null); 
        jtfEmail.setText(null);
        jtfEstadoCivil.setText(null);
        jtfNaturalidade.setText(null);
        jtfapelido.setText(null);
        jtfaObservacao.setText(null);
        jtfSalario.setText(null);
        jtfEndereco.setText(null);
        jtfCodigo.setText(null);
        readJTable();

    }//GEN-LAST:event_jbtGravarActionPerformed

    private void tabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseClicked
        if (tabela.getSelectedRow() != -1) {
            jtfNome.setText(tabela.getValueAt(tabela.getSelectedRow(), 1).toString());
            jtfDataDeNascimento.setText(tabela.getValueAt(tabela.getSelectedRow(), 2).toString());
            jcbSexo.setSelectedItem(tabela.getValueAt(tabela.getSelectedRow(), 3).toString());
            jtfnrBI.setText(tabela.getValueAt(tabela.getSelectedRow(), 4).toString());
            jtfSalario.setText(tabela.getValueAt(tabela.getSelectedRow(), 5).toString());
             jtfNaturalidade.setText(tabela.getValueAt(tabela.getSelectedRow(), 6).toString());
             jtfEmail.setText(tabela.getValueAt(tabela.getSelectedRow(), 7).toString());
             jtfEndereco.setText(tabela.getValueAt(tabela.getSelectedRow(), 8).toString());
             jtfEstadoCivil.setText(tabela.getValueAt(tabela.getSelectedRow(), 9).toString());
             jtfContacto.setText(tabela.getValueAt(tabela.getSelectedRow(), 10).toString());
             jtfaObservacao.setText(tabela.getValueAt(tabela.getSelectedRow(), 11).toString());
              jtfapelido.setText(tabela.getValueAt(tabela.getSelectedRow(), 12).toString());
             jtfnrBI.setText(tabela.getValueAt(tabela.getSelectedRow(), 13).toString());
        }
    }//GEN-LAST:event_tabelaMouseClicked
    /**
     * Metodo reesponsavel por Pesquisar o funcionario no ficheiro.
     *
     * @param evt
     */
    private void jbtPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtPesquisarActionPerformed
       Funcionario a = new Funcionario();

        a.setNome(jtfNome.getText());
        a.setCodigo(Integer.parseInt("0" + jtfCodigo.getText()));
        a.setDataNascimento(jtfDataDeNascimento.getText());
        a.setSexo((String) jcbSexo.getSelectedItem());
        a.setNrBI(Integer.parseInt("0"+ jtfnrBI.getText()));
        a.setSalario(Double.parseDouble("0" + jtfSalario.getText()));

        readJTable1(a);
    }//GEN-LAST:event_jbtPesquisarActionPerformed

    private void jbtLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtLimparActionPerformed
        jtfNome.setText(null);
        jtfapelido.setText(null);
        jtfDataDeNascimento.setText(null);
        jtfnrBI.setText(null);
        jtfCodigo.setText(null);
        jtfNaturalidade.setText(null);
        jtfEstadoCivil.setText(null);
        jtfEmail.setText(null);
        jtfContacto.setText(null);
        jtfEndereco.setText(null);
        jtfaObservacao.setText(null);
        jcbSexo.setSelectedIndex(0);
        jtfSalario.setText(null);
        readJTable();
    }//GEN-LAST:event_jbtLimparActionPerformed

    private void tabelaAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tabelaAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tabelaAncestorAdded

    /**
     * Metodo reesponsavel por actualizar o funcionario no ficheiro.
     *
     * @param evt
     */
    private void jbtActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtActualizarActionPerformed
        if (tabela.getSelectedRow() != -1) {
            Funcionario a = new Funcionario();
        a.setNome(jtfNome.getText());
        a.setCodigo(Integer.parseInt(jtfCodigo.getText()));
        a.setApelido(jtfapelido.getText());
        a.setNaturalidade(jtfNaturalidade.getText());
        a.setEmail(jtfEmail.getText());
        a.setContacto(Integer.parseInt(jtfContacto.getText()));
        a.setEstadoCivil(jtfEstadoCivil.getText());
        a.setObservacao(jtfaObservacao.getText());
        a.setDataNascimento(jtfDataDeNascimento.getText());
        a.setSexo((String) jcbSexo.getSelectedItem());
        a.setNrBI(Integer.parseInt(jtfnrBI.getText()));
        a.setSalario(Double.parseDouble(jtfSalario.getText()));
        a.setEndereco(jtfEndereco.getText());
        

            FuncionarioDAO.update(a);

            readJTable();
            JOptionPane.showMessageDialog(null, "Actualizado com sucesso.");
        }
    }//GEN-LAST:event_jbtActualizarActionPerformed

    /**
     * Metodo reesponsavel por remover o funcionario no ficheiro.
     *
     * @param evt
     */
    private void jbtRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtRemoverActionPerformed
        if (tabela.getSelectedRow() != -1) {
            Funcionario a = new Funcionario();

            a.setCodigo(Integer.parseInt(tabela.getValueAt(
                    tabela.getSelectedRow(), 0).toString()));

            FuncionarioDAO.delete(a);

            readJTable();
            JOptionPane.showMessageDialog(null, "Removido com sucesso.");

        }
    }//GEN-LAST:event_jbtRemoverActionPerformed

    private void jtfSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfSalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfSalarioActionPerformed

    private void jtfNaturalidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfNaturalidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfNaturalidadeActionPerformed

    public void readJTable() {
        DefaultTableModel modelo1 = (DefaultTableModel) tabela.getModel();
        modelo1.setNumRows(0);

        for (Funcionario a : FuncionarioDAO.read()) {
            if (a.getSexo().equalsIgnoreCase("Masculino")) {
                modelo1.addRow(new Object[]{a.getCodigo(), a.getNome(),
                    a.getDataNascimento(), a.getApelido(),a.getContacto(),a.getEmail(),
                    a.getEndereco(),a.getNaturalidade(),a.getNrBI(),a.getEstadoCivil(),
                    a.getObservacao(),a.getSexo(), a.getSalario()

                });
            } else if (a.getSexo().equalsIgnoreCase("femenino")) {
                modelo1.addRow(new Object[]{a.getCodigo(), a.getNome(),
                    a.getDataNascimento(), a.getApelido(),a.getContacto(),a.getEmail(),
                    a.getEndereco(),a.getNaturalidade(),a.getNrBI(),a.getEstadoCivil(),
                    a.getObservacao(),a.getSexo(), a.getSalario()


                });
            
                
            }

        }
    }

    public void readJTable1(Funcionario funcionario) {
        DefaultTableModel modelo1 = (DefaultTableModel) tabela.getModel();
        modelo1.setNumRows(0);

        for (Funcionario a : FuncionarioDAO.buscarDados(funcionario)) {

            modelo1.addRow(new Object[]{a.getCodigo(), a.getNome(),
                    a.getDataNascimento(), a.getApelido(),a.getContacto(),a.getEmail(),
                    a.getEndereco(),a.getNaturalidade(),a.getNrBI(),a.getEstadoCivil(),
                    a.getObservacao(),a.getSexo(), a.getSalario()

            });

        }

    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistarFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jblEmail;
    private javax.swing.JLabel jblObservacao;
    private javax.swing.JButton jbtActualizar;
    private javax.swing.JButton jbtGravar;
    private javax.swing.JButton jbtLimpar;
    private javax.swing.JButton jbtPesquisar;
    private javax.swing.JButton jbtRemover;
    private javax.swing.JComboBox<String> jcbSexo;
    private javax.swing.JLabel jlblContacto;
    private javax.swing.JLabel jlblEstadoCivil;
    private javax.swing.JLabel jlblNaturalidade;
    private javax.swing.JLabel jlblenderco;
    private javax.swing.JLabel jlblsexo;
    private javax.swing.JTextField jtfCodigo;
    private javax.swing.JTextField jtfContacto;
    private javax.swing.JTextField jtfDataDeNascimento;
    private javax.swing.JTextField jtfEmail;
    private javax.swing.JTextField jtfEndereco;
    private javax.swing.JTextField jtfEstadoCivil;
    private javax.swing.JTextField jtfNaturalidade;
    private javax.swing.JTextField jtfNome;
    private javax.swing.JTextField jtfSalario;
    private javax.swing.JTextArea jtfaObservacao;
    private javax.swing.JTextField jtfapelido;
    private javax.swing.JTextField jtfnrBI;
    private javax.swing.JLabel lblApelido;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblDataDeIngresso;
    private javax.swing.JLabel lblDataRegisto;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSalario;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
