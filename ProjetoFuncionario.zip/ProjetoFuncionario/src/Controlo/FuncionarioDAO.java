/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import Modelo.Funcionario;

/**
 * Classe responsavel pelo controlo do funcionario.
 *
 * @version 1.0
 */
public class FuncionarioDAO {

    private static final String NOME_FICHEIRO = "func.dat";

    private static final String FICHEIRO = "func.txt";

    /**
     * Metodo que cria o funcionario no ficheiro.
     *
     * @param a objecto do tipo funcionario.
     */
    public static void create(Funcionario a) {
        a.setCodigo(generateNextCodigo());
        List<Funcionario> funcionarios = read();
        funcionarios.add(a);
        create(funcionarios);
        gravarCodigo(a.getCodigo());
    }

    /**
     * Metodo que actualiza o funcionario no ficheiro.
     *
     * @param a objecto do tipo funcionario.
     */
    public static void update(Funcionario a) {
        List<Funcionario> funcionarios = read();
        funcionarios.remove(a);
        funcionarios.add(a);
        create(funcionarios);
    }

    /**
     * Metodo que delete o funcionario no ficheiro.
     *
     * @param a objecto do tipo funcionario.
     */
    public static void delete(Funcionario a) {
        List<Funcionario> funcionarios = read();
        funcionarios.remove(a);
        create(funcionarios);
    }

    /**
     * Metodo que faz a leitura dos funcionarios no ficheiro.
     *
     * @return retorna os funcionarios
     */
    public static List<Funcionario> read() {
        List<Funcionario> funcionarios = new ArrayList();
        try {
            FileInputStream f = new FileInputStream(NOME_FICHEIRO);
            ObjectInputStream objStream = new ObjectInputStream(f);
            List<Funcionario> funcion;
            try {
                while ((funcion = (List<Funcionario>) objStream.readObject()) != null) {
                    funcionarios.addAll(funcion);
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (EOFException eo) {
            System.out.println("Fim do ficheiro!");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return funcionarios;

    }

    /**
     * @param a objecro da classe funcionario
     * @return retorna o resultado da pesquisa Faz a busca dos dados no Ficheiro
     * e retorna o objecro requisitado
     */
   public static List<Funcionario> buscarDados(Funcionario a) {

		List<Funcionario> funcionarios = read();
		List<Funcionario> eventoResult = new ArrayList<Funcionario>();

		for (Funcionario funcionario : funcionarios) {
			boolean adcionar = false;

			if (a.getNome()!= null && !a.getNome().equalsIgnoreCase("")) {
				if (a.getNome().equalsIgnoreCase(funcionario.getNome())) {
					adcionar = true;
				} else {
					adcionar = false;
				}

				
			}
			if (a.getSexo()!= null
					&& !a.getSexo().equalsIgnoreCase("")) {
				if (a.getSexo().equalsIgnoreCase(
						funcionario.getSexo())) {
					adcionar = true;
				} else {
					adcionar = false;
				}
		}
                        if (a.getCodigo()!= 0){
				if (a.getCodigo()==funcionario.getCodigo()) {
					adcionar = true;
				} else {
					adcionar = false;
				}

				
			}
			if (adcionar) {
				eventoResult.add(funcionario);
			}
		
		}
		return eventoResult;
		
	}
    
    /**
     * Metodo que gera o codigo.
     * @return retorno o proximo codico.
     */
    private static int generateNextCodigo() {
        return lerCodigo() + 1;
    }

    /**
     *Metodo que grava o codico no ficheiro.
     * @param codigo codigo que pretende se gravar,
     */
    private static void gravarCodigo(int codigo) {
        try {
            BufferedWriter bwr = new BufferedWriter(new FileWriter(FICHEIRO));
            String str = "";
            str = String.valueOf(codigo);
            bwr.write(str);
            bwr.flush();
            bwr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo que faz a leitura do codico no ficheiro.
     * @return 
     */
    private static int lerCodigo() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(FICHEIRO));
            int codigo = Integer.parseInt("0" + br.readLine());
            return codigo;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
        }

        return 0;
    }

    /**
     * Metodo responsavel por criar funcionarios.
     * @param funcionarios que pretende se criar.
     */
    private static void create(List<Funcionario> funcionarios) {
        try {
            FileOutputStream out = new FileOutputStream(NOME_FICHEIRO);
            ObjectOutputStream objStrim = new ObjectOutputStream(out);
            objStrim.writeObject(funcionarios);
            objStrim.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
